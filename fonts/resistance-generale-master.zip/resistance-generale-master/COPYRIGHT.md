Copyright (c) 2005-2013, Jane Doe <jane@jane@university.edu>
Copyright (c) 2007, Pat Johnson <pat@fontstudio.org>
Copyright (c) 2006, Fred Foobar <fred@foobar.org>
Copyright (c) 2005, Tom Parker <tom@company.com>
Copyright (c) 2005, Joe Smith <joe@fontstudio.org>